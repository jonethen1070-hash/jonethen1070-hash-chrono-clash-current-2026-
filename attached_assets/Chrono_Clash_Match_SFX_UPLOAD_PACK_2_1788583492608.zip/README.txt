CHRONO CLASH MATCH SFX

match_1.wav = 1st match wave
match_2.wav = 2nd match/cascade wave
match_3.wav = 3rd match/cascade wave
match_4.wav = 4th match/cascade wave
match_5.wav = 5th+ match/cascade wave

Use ONE Match SFX per match wave, never once per matched gem.
